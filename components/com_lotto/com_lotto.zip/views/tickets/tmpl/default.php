<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Lotto
 * @author     flance ltd <tutyou1972@gmail.com>
 * @copyright  2018 flance LTD
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$user       = JFactory::getUser();
$userId     = $user->get('id');
$listOrder  = $this->state->get('list.ordering');
$listDirn   = $this->state->get('list.direction');
$canCreate  = $user->authorise('core.create', 'com_lotto') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'userform.xml');
$canEdit    = $user->authorise('core.edit', 'com_lotto') && file_exists(JPATH_COMPONENT . DIRECTORY_SEPARATOR . 'models' . DIRECTORY_SEPARATOR . 'forms' . DIRECTORY_SEPARATOR . 'userform.xml');
$canCheckin = $user->authorise('core.manage', 'com_lotto');
$canChange  = $user->authorise('core.edit.state', 'com_lotto');
$canDelete  = $user->authorise('core.delete', 'com_lotto');
?>

<form action="<?php echo htmlspecialchars(JUri::getInstance()->toString()); ?>" method="post"
      name="adminForm" id="adminForm">

	
	<table class="table table-striped" id="userList">
		<thead>
		<tr class="tickets_table_th">

            <th class='left tickets_table_th'>
                <?php echo JText::_('COM_LOTTO_USERS_TICKETS_TIRAJ'); ?>
            </th>

            <th class='left tickets_table_th'>
                <?php echo JText::_('COM_LOTTO_TICKETS_ID'); ?>
            </th>
            <th class='left tickets_table_th'>
                <?php echo JText::_('COM_LOTTO_NUMBERS'); ?>
            </th>
            <th class='left tickets_table_th'>
                <?php echo JText::_('COM_LOTTO_WIN') ?>
            </th>



        </tr>

		</thead>
		<tfoot>
		<tr class="tickets_table_th">
			<td class="tickets_table_th" colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
				<?php echo $this->pagination->getListFooter(); ?>
			</td>
		</tr>
		</tfoot>
		<tbody>
		<?php
        if (count($this->items)):

        foreach ($this->items as $i => $item) : ?>
			<?php $canEdit = $user->authorise('core.edit', 'com_lotto'); ?>

			
			<tr class="row<?php echo $i % 2; ?>">
                <td class="tickets_table_th">

                    <?php echo $item->tickets_tiraj_numbers; ?>
                </td >

                <td class="tickets_table_th">

					<?php echo $item->tickets_id; ?>
				</td>

                <td class="tickets_table_th">
                    <?php echo $item->numbers; ?>

                </td>

                <td class="tickets_table_th">
                   Выыгриш

                </td>


			</tr>
		<?php endforeach;
        else:
           echo '<tr class="row_1"><td colspan="5">' ;

            echo JText::_('COM_LOTTO_NO_TICKETS');
            echo '</td></tr>';

        endif;
        ?>
		</tbody>
	</table>

	<?php if ($canCreate) : ?>
		<a href="<?php echo JRoute::_('index.php?option=com_lotto&task=userform.edit&id=0', false, 0); ?>"
		   class="btn btn-success btn-small"><i
				class="icon-plus"></i>
			<?php echo JText::_('COM_LOTTO_ADD_ITEM'); ?></a>
	<?php endif; ?>

	<input type="hidden" name="task" value=""/>
	<input type="hidden" name="boxchecked" value="0"/>
	<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>"/>
	<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>"/>
	<?php echo JHtml::_('form.token'); ?>
</form>

<?php if($canDelete) : ?>
<script type="text/javascript">

	jQuery(document).ready(function () {
		jQuery('.delete-button').click(deleteItem);
	});

	function deleteItem() {

		if (!confirm("<?php echo JText::_('COM_LOTTO_DELETE_MESSAGE'); ?>")) {
			return false;
		}
	}
</script>
<?php endif; ?>
